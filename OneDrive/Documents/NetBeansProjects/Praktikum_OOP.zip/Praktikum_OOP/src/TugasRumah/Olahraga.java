package TugasRumah;

public class Olahraga extends Gizi {
    private String namaOlahraga;
    private int durasi; // dalam menit
    private int kaloriTerbakar;

    public Olahraga(String nama, double beratBadan, double tinggiBadan, int usia, String jenisKelamin, double faktorAktivitas, String namaOlahraga, int durasi, int kaloriTerbakar) {
        super(nama, beratBadan, tinggiBadan, usia, jenisKelamin, faktorAktivitas);
        this.namaOlahraga = namaOlahraga;
        this.durasi = durasi;
        this.kaloriTerbakar = kaloriTerbakar;
    }

    public int getKaloriTerbakar() {
        return kaloriTerbakar;
    }

    public String infoOlahraga() {
        return "Olahraga: " + namaOlahraga +
               "\nDurasi: " + durasi + " menit" +
               "\nKalori Terbakar: " + kaloriTerbakar + " kcal";
    }
}