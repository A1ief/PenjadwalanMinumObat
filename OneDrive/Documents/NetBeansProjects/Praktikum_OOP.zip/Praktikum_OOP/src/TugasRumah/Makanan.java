package TugasRumah;

public class Makanan extends Gizi {
    private String namaMakanan;
    private int kalori;

    // Constructor harus menyesuaikan constructor Gizi
    public Makanan(String nama, double beratBadan, double tinggiBadan, int usia, 
                   String jenisKelamin, double faktorAktivitas,
                   String namaMakanan, int kalori) {
        super(nama, beratBadan, tinggiBadan, usia, jenisKelamin, faktorAktivitas);
        this.namaMakanan = namaMakanan;
        this.kalori = kalori;
    }

    public String infoMakanan() { 
        return "Nama Makanan: " + namaMakanan + "\nKalori: " + kalori + " kcal";
    }
}
