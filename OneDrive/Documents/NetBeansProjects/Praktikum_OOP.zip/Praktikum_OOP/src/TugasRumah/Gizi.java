package TugasRumah;

public class Gizi {
    protected String nama;
    protected String jenisKelamin; // "pria" atau "wanita"
    protected int usia;
    protected double beratBadan, tinggiBadan, faktorAktivitas;

    // Constructor
    public Gizi(String nama, double beratBadan, double tinggiBadan, int usia, String jenisKelamin, double faktorAktivitas) {
        this.nama = nama;
        this.usia = usia;
        this.beratBadan = beratBadan;
        this.tinggiBadan = tinggiBadan;
        this.jenisKelamin = jenisKelamin.toLowerCase(); // aman dari kapitalisasi
        this.faktorAktivitas = faktorAktivitas;
    }

    // Fungsi menghitung kebutuhan kalori menggunakan rumus Mifflin-St Jeor
    public double kebutuhanKalori() {
        double BMR;
        if (jenisKelamin.equals("pria")) {
            BMR = (10 * beratBadan) + (6.25 * tinggiBadan) - (5 * usia) + 5;
        } else {
            BMR = (10 * beratBadan) + (6.25 * tinggiBadan) - (5 * usia) - 161;
        }
        return BMR * faktorAktivitas;
    }

    // Menampilkan informasi
    public String infoGizi() {
        return "Nama: " + nama +
               "\nJenis Kelamin: " + jenisKelamin +
               "\nUsia: " + usia + " tahun" +
               "\nBerat Badan: " + beratBadan + " kg" +
               "\nTinggi Badan: " + tinggiBadan + " cm" +
               "\nKebutuhan Kalori: " + String.format("%.2f", kebutuhanKalori()) + " kcal";
    }
}
