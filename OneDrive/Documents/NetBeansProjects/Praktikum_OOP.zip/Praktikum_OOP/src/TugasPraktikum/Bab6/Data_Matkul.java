/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TugasPraktukum.Bab6;

/**
 *
 * @author athal
 */
public class Data_Matkul {
    String kode_mk;
    String nama_mk;
    String dosen_pengampu;
    int jumlah_sks;
    
    public Data_Matkul(String kode, String mk, String dsn, int jmlsks) {
        this.kode_mk = kode;
        this.nama_mk = mk;
        this.dosen_pengampu = dsn;
        this.jumlah_sks = jmlsks;
    }
}
