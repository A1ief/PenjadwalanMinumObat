/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BAB4.Enkapsulasi;

/**
 *
 * @author sabas
 */
public class HitungLimas {

    // Deklarasi variabel dengan hak akses yang sesuai
    private double luasAlas;
    public double tinggi;
    double volume;

    // Setter dan getter untuk atribut luasAlas
    public void setLuasAlas(double luasAlas) {
        this.luasAlas = luasAlas;
    }

    public double getLuasAlas() {
        return luasAlas;
    }

    // Method untuk menghitung volume limas
    double volumeLimas() {
        volume = (luasAlas * tinggi) / 3;
        return volume;
    }

    public static void main(String[] args) {
        // Contoh penggunaan class HitungLimas
        HitungLimas limas = new HitungLimas();

        limas.setLuasAlas(20.0); // Mengatur nilai luas alas
        limas.tinggi = 15.0;    // Mengatur nilai tinggi secara langsung

        // Menghitung dan menampilkan volume limas
        System.out.println("Volume limas: " + limas.volumeLimas());
    }
}
