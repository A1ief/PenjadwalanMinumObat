/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BAB6.Abstract;

/**
 *
 * @author sabas
 */
public class JajajrGenjang extends BangunDatarSegiEmpat{
    double a,t,b;
    public JajajrGenjang(){
        this.a = 8;
        this.t = 3;
        this.b = 9;
    }
    @Override
    double luas() {
        return (a*t);
    }

    @Override
    double keliling() {
        return (2*(a+b));
    } 
}

