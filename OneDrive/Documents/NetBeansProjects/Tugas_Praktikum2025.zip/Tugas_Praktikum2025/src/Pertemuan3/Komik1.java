package Pertemuan3; 
 
public class Komik1 { 
    private String judul; 
    private String penulis; 
    private int eps;
    private String genre; 
 
    // Konstruktor 
    public Komik1(String judul, String penulis, int eps,String genre) { 
        this.judul = judul; 
        this.penulis = penulis; 
         this.eps = eps;
        this.genre = genre; 
    } 
    // Getter untuk mendapatkan informasi buku 
    public String getJudul() { 
        return judul; 
    } 
    public String getPenulis() { 
        return penulis; 
    }  
    public int getEps() { 
        return eps; 
    } 
    public String getGenre() { 
        return genre; 
    } 
    // Metode untuk menampilkan informasi buku 
    public void tampilkanInfo() { 
        System.out.println("Judul       : " + judul); 
        System.out.println("Penulis     : " + penulis);
         System.out.println("Episode: " + eps);
        System.out.println("Genre    : " + genre); 
        System.out.println("----------------------------------"); 
    } 
} 
