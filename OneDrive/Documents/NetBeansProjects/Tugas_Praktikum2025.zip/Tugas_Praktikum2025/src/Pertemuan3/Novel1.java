package Pertemuan3; 
 
public class Novel1 { 
    private String judul; 
    private String penulis; 
    private int tahunTerbit; 
    private String genre; 
 
    // Konstruktor 
    public Novel1(String judul, String penulis, int tahunTerbit, String genre) { 
        this.judul = judul; 
        this.penulis = penulis; 
        this.tahunTerbit = tahunTerbit; 
        this.genre = genre; 
    } 
    // Getter untuk mendapatkan informasi buku 
    public String getJudul() { 
        return judul; 
    } 
    public String getPenulis() { 
        return penulis; 
    } 
    public int getTahunTerbit() { 
        return tahunTerbit; 
    } 
    public String getGenre() { 
        return genre; 
    } 
    // Metode untuk menampilkan informasi buku 
    public void tampilkanInfo() { 
        System.out.println("Judul       : " + judul); 
        System.out.println("Penulis     : " + penulis); 
        System.out.println("Tahun Terbit: " + tahunTerbit); 
        System.out.println("Genre    : " + genre); 
        System.out.println("----------------------------------"); 
    } 
} 
